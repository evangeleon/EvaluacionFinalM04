
================================================================================
Human idea Page ==================================================================
================================================================================
Página web basada en html y javascript la cual administra los principales procesos de
negocio, planificación de actividades y control de ejecución que se llevan a
cabo día a día en empresas de asesorías en prevención de riesgo. 

En respuesta para empresas que no poseen un sistema que les permita 
administrar toda la cantidad de información que se genera, ni controlar las 
actividades y el recurso humano. 

Esta pagina permite una mejor gestión, control, seguridad, y disponibilidad 
de información para la empresa y sus clientes, almacenandola y ordenandola según
el tipo de perfil al que corresponda: Clientes, profesionales y administrativos, la creacion de capacitaciones, pagos y asesorias,
ademas de la generacion de reportes


Esta pagina se divide en las siguientes secciones:

- Inicio
- Contacto
- Crear Capacitación
- Listar Capacitación
- Login
- Listado de Usuarios
- Crear Usuario
- Editar Cliente
- Editar Administrativo
- Editar Profesional

================================================================================
Versión ========================================================================
================================================================================

CrossVisions ===================================================================

Versión 1.0 alfa versiones anteriores a la distribució.n

Versión 1.0 14-03-2021 Primera versión: Visualización html. 

Versión 2.0 29-03-2021 Seguda versión alfa. 


================================================================================
Licencia =======================================================================
================================================================================

Autores
------------------------

Grupo 2:

- Daniel Estrada    --> https://github.com/DanielEstradaMallea/EvaluacionFinalM04.git
- Evange León       --> https://github.com/evangeleon/EvaluacionFinalM04.git
- Hugo López        --> https://github.com/HugoLopezug/EvaluacionFinalM04.git
- Cristian Guerrero --> https://github.com/elegangsters/EvaluacionFinalM04.git
- Jonathan Urrutia --> https://github.com/Jona053/Jonathan-EvaluacionFinalM04.git

Awakelab
Talento Digital 


Copias y distribución:
----------------------

- Usted puede hacer las copia que quiera de este código

- No se permite la venta excepto si el pago corresponde al coste
del soporte  (discos, cintas, CD-ROM, etc).

ATENCION:
    Este codigo no tiene ninguna garantia y los autores no se hacen
    responsables de los posibles perjuicios causados por su uso.
    Usted asume los riesgos del uso de este código

WARNING:
    This software comes with ABSOLUTELY NO WARRANTEE.
    USE AT YOUR OWN RISK!