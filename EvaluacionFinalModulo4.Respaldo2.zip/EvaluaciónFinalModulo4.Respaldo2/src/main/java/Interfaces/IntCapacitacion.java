package Interfaces;

import java.util.List;
import Modelo.Capacitacion;

public interface IntCapacitacion {
	
	public List<Capacitacion> obtenerCapacitacion();
	
	public Integer subirCapacitacion(Capacitacion subir); 

}
